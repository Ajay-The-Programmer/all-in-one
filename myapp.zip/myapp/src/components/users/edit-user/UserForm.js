import { Button, Drawer, Grid2, TextField, Typography } from "@mui/material";
import React, { useEffect } from "react";
import { Controller, useForm } from "react-hook-form";

export default function UserForm({ openDrawer, setOpenDrawer, selectedUser, setUsers }) {
  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();

  useEffect(() => {
    reset(selectedUser);
  }, [selectedUser]);

  const toggleDrawer = (isOpen) => {
    setOpenDrawer(isOpen);
  };

  const saveUserForm = (userInfo) => {
    setUsers((prev) =>
      prev.map((user) => {
        if (user.id === userInfo.id) {
          return userInfo;
        }
        return user;
      })
    );
    reset();
    setOpenDrawer(false);
  };

  return (
    <Drawer anchor="right" open={openDrawer} onClose={() => toggleDrawer(false)}>
      <Typography
        variant="h5"
        component={"h5"}
        sx={{ display: "flex", justifyContent: "center", m: "2%", fontWeight: "500" }}
      >
        Update User
      </Typography>
      <form onSubmit={handleSubmit(saveUserForm)}>
        <Grid2 container spacing={2} sx={{ m: "15px" }}>
          <Grid2 item size={{ xs: 12, sm: 12, md: 12, lg: 12 }}>
            <Controller
              name="title"
              control={control}
              rules={{ required: "Title is required" }}
              render={({ field }) => (
                <TextField
                  {...field}
                  fullWidth
                  label="Title"
                  variant="outlined"
                  error={Boolean(errors.title)}
                  helperText={errors.title ? errors.title.message : ""}
                />
              )}
            />
          </Grid2>
          <Grid2 item size={{ xs: 12, sm: 12 }}>
            <Controller
              name="body"
              control={control}
              rules={{
                required: "Body is required",
              }}
              render={({ field }) => (
                <TextField
                  {...field}
                  fullWidth
                  label="Body"
                  variant="outlined"
                  error={Boolean(errors.body)}
                  helperText={errors.body ? errors.body.message : ""}
                />
              )}
            />
          </Grid2>
          <Grid2 item size={{ xs: 12, sm: 12 }}>
            <Button
              variant="contained"
              size="small"
              sx={{ display: "block", ml: "auto", fontWeight: "500" }}
              type="submit"
            >
              Update
            </Button>
          </Grid2>
        </Grid2>
      </form>
    </Drawer>
  );
}
