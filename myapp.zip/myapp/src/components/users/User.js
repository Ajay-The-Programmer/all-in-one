import React, { useEffect, useState } from "react";
import axios from "axios";
import { Box, Button, Table, TableBody, TableCell, TableHead, TableRow } from "@mui/material";
import UserForm from "./edit-user/UserForm";

function User() {
  const [users, setUsers] = useState([]);
  const [openDrawer, setOpenDrawer] = useState(false);
  const [selectedUser, setSelectedUser] = useState({});

  useEffect(() => {
    const getUsers = async () => {
      axios
        .get("https://jsonplaceholder.typicode.com/posts")
        .then((result) => {
          setUsers(result.data);
        })
        .catch((err) => {
          console.log(err);
        });
    };

    getUsers();
  }, []);

  const handleEditUser = (user) => {
    setOpenDrawer(true);
    setSelectedUser(user);
  };

  console.log("users", users);

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        maxWidth: "80%",
        width: "100%",
      }}
    >
      <Table border="1" size="medium">
        <TableHead>
          <TableCell align="center">Title</TableCell>
          <TableCell align="center">Body</TableCell>
          <TableCell align="center">Action</TableCell>
        </TableHead>
        <TableBody>
          {users?.map((user) => (
            <TableRow key={user.id}>
              <TableCell align="center">{user.title}</TableCell>
              <TableCell align="center">{user.body}</TableCell>
              <TableCell align="center">
                <Button variant="contained" onClick={() => handleEditUser(user)}>
                  Edit
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <UserForm
        openDrawer={openDrawer}
        setOpenDrawer={setOpenDrawer}
        selectedUser={selectedUser}
        setUsers={setUsers}
      />
    </Box>
  );
}

export default User;
// aadil@nowappstech.com
